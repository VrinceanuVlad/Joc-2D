using UnityEngine;

public class GameplayManager : MonoBehaviour
{
    public static GameplayManager Instance;
    [SerializeField] LosePanel losePanel;

    private void Awake()
    {
        Instance = this;
    }

    public void Lost()
    {
        int _gold = FindObjectOfType<GoldHandler>().Gold;
        DataManager.Instance.PlayerData.Gold += _gold;
        losePanel.Setup();
    }
}
