using UnityEngine;

public class UFOSpawner : MonoBehaviour
{
    [SerializeField] float spawnDelay;
    [SerializeField] UFOController ufoPrefab;
    [SerializeField] Transform leftBoundrie;
    [SerializeField] Transform rightBoundrie;
    [SerializeField] Transform yTarget;
    float counter = 0;

    private void Update()
    {
        counter += Time.deltaTime;
        if (counter > spawnDelay)
        {
            counter = 0;
            Vector3 _spawnPosition = new Vector3();
            _spawnPosition.x = Random.Range(leftBoundrie.position.x, rightBoundrie.position.x);
            _spawnPosition.y = leftBoundrie.position.y;
            UFOController _ufo = Instantiate(ufoPrefab);
            _ufo.Setup(_spawnPosition, yTarget.position);
        }
    }
}
