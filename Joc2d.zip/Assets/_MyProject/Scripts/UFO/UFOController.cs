using System;
using UnityEngine;

public class UFOController : MonoBehaviour
{
    public static Action Destroyed;

    [SerializeField] float flySpeed;
    [SerializeField] float attackCooldown;
    [SerializeField] Bullet bulletPrefab;
    [SerializeField] Transform shootPointer;
    Transform myTransform;
    Vector3 yTarget;

    float counter = 0;

    public void Setup(Vector3 _spawnPosition, Vector3 _yTarget)
    {
        transform.position = _spawnPosition;
        yTarget = transform.position;
        yTarget.y = _yTarget.y;
    }

    private void Awake()
    {
        myTransform = GetComponent<Transform>();
    }


    private void FixedUpdate()
    {
        if (yTarget == default)
        {
            return;
        }
        counter += Time.deltaTime;

        if (counter > attackCooldown)
        {
            counter = 0;
            Bullet _bullet = Instantiate(bulletPrefab);
            _bullet.transform.position = shootPointer.position;
        }

        myTransform.position = Vector3.MoveTowards(myTransform.position, yTarget, flySpeed * Time.deltaTime);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "MyBullet")
        {
            AudioManager.Instance.PlayExplosion();
            Destroy(gameObject);
            Destroyed?.Invoke();
        }
    }
}
