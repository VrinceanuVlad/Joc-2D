using UnityEngine;
using TMPro;

public class GoldHandler : MonoBehaviour
{
    [SerializeField] TextMeshProUGUI goldDisplay;
    int gold = 0;

    public int Gold => gold;

    private void OnEnable()
    {
        UFOController.Destroyed += IncreaseGold;
    }

    private void OnDisable()
    {
        UFOController.Destroyed -= IncreaseGold;
    }

    void IncreaseGold()
    {
        gold += 1;
        ShowScore();
    }

    private void Start()
    {
        ShowScore();
    }

    void ShowScore()
    {
        goldDisplay.text = "x" + gold;
    }
}
