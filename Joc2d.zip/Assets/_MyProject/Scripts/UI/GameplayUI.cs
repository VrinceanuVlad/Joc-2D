using UnityEngine;
using UnityEngine.UI;

public class GameplayUI : MonoBehaviour
{
    [SerializeField] PausePanel pausePanel;
    [SerializeField] Button pauseButton;

    private void OnEnable()
    {
        pauseButton.onClick.AddListener(ShowPause);
    }

    private void OnDisable()
    {
        pauseButton.onClick.RemoveListener(ShowPause);
    }

    void ShowPause()
    {
        pausePanel.Setup();
    }
}
