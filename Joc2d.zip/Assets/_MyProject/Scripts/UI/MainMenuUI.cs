using UnityEngine;
using UnityEngine.UI;

public class MainMenuUI : MonoBehaviour
{
    [SerializeField] Button playButton;
    [SerializeField] Button shopButton;
    [SerializeField] Button settingsButton;

    [SerializeField] ShopPanel shopPanel;
    [SerializeField] SettingsPanel settingsPanel;

    private void OnEnable()
    {
        playButton.onClick.AddListener(Play);
        settingsButton.onClick.AddListener(ShowSettings);
        shopButton.onClick.AddListener(ShowShop);
    }

    private void OnDisable()
    {
        playButton.onClick.RemoveListener(Play);
        settingsButton.onClick.RemoveListener(ShowSettings);
        shopButton.onClick.RemoveListener(ShowShop);
    }

    void Play()
    {
        SceneManager.LoadGameplay();
    }

    void ShowShop()
    {
        shopPanel.Setup();
    }

    void ShowSettings()
    {
        settingsPanel.Setup();
    }
}
