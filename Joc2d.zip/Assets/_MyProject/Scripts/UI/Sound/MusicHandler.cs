using UnityEngine;
using UnityEngine.UI;

public class MusicHandler : MonoBehaviour
{
    Button button;
    Image image;

    private void Awake()
    {
        button = GetComponent<Button>();
        image = GetComponent<Image>();
    }

    private void OnEnable()
    {
        button.onClick.AddListener(Change);
        PlayerData.UpdatedMusic += ShowGraphics;
        ShowGraphics();
    }

    private void OnDisable()
    {
        button.onClick.RemoveListener(Change);
        PlayerData.UpdatedMusic -= ShowGraphics;
    }

    void Change()
    {
        DataManager.Instance.PlayerData.PlayMusic = !DataManager.Instance.PlayerData.PlayMusic;
    }

    void ShowGraphics()
    {
        image.color = DataManager.Instance.PlayerData.PlayMusic ? Color.white : Color.grey;
    }
}
