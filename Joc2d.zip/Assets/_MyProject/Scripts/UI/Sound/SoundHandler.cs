using UnityEngine;
using UnityEngine.UI;

public class SoundHandler : MonoBehaviour
{
    Button button;
    Image image;

    private void Awake()
    {
        button = GetComponent<Button>();
        image = GetComponent<Image>();
    }

    private void OnEnable()
    {
        button.onClick.AddListener(Change);
        PlayerData.UpdatedSound += ShowGraphics;
        ShowGraphics();
    }

    private void OnDisable()
    {
        button.onClick.RemoveListener(Change);
        PlayerData.UpdatedSound -= ShowGraphics;
    }

    void Change()
    {
        DataManager.Instance.PlayerData.PlaySound = !DataManager.Instance.PlayerData.PlaySound;
    }

    void ShowGraphics()
    {
        image.color = DataManager.Instance.PlayerData.PlaySound ? Color.white : Color.grey;
    }
}
