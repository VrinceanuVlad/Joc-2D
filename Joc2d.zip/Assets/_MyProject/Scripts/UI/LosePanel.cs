using UnityEngine;
using UnityEngine.UI;

public class LosePanel : MonoBehaviour
{
    [SerializeField] Button menuButton;
    [SerializeField] Button replayButton;

    private void OnEnable()
    {
        menuButton.onClick.AddListener(ShowMenu);
        replayButton.onClick.AddListener(Replay);
        Time.timeScale = 0;
    }

    private void OnDisable()
    {
        menuButton.onClick.RemoveListener(ShowMenu);
        replayButton.onClick.RemoveListener(Replay);
        Time.timeScale = 1;
    }

    void ShowMenu()
    {
        SceneManager.LoadMainMenu();
    }

    void Replay()
    {
        SceneManager.LoadGameplay();
    }

    public void Setup()
    {
        gameObject.SetActive(true);
    }
}
