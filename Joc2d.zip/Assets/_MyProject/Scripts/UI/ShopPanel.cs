using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

public class ShopPanel : MonoBehaviour
{
    [SerializeField] Button closeButton;
    [SerializeField] Button nextButton;
    [SerializeField] Button previousButton;
    [SerializeField] Button actionButton;
    [SerializeField] Image shipDisplay;
    [SerializeField] TextMeshProUGUI actionText;
    [SerializeField] TextMeshProUGUI goldDisplay;
    List<ShipSO> ships;
    int selectedShip = 0;

    private void Awake()
    {
        ships = ShipSO.GetAll();
    }

    private void OnEnable()
    {
        closeButton.onClick.AddListener(Close);

        nextButton.onClick.AddListener(ShowNext);
        previousButton.onClick.AddListener(ShowPrevious);
    }

    private void OnDisable()
    {
        closeButton.onClick.RemoveListener(Close);

        nextButton.onClick.RemoveListener(ShowNext);
        previousButton.onClick.RemoveListener(ShowPrevious);
    }
    public void Close()
    {
        gameObject.SetActive(false);
    }

    public void Setup()
    {
        gameObject.SetActive(true);
        selectedShip = 0;
        ShowGold();
        ShowShip();
    }

    void ShowGold()
    {
        goldDisplay.text = "x" + DataManager.Instance.PlayerData.Gold;
    }


    void ShowNext()
    {
        selectedShip++;
        if (selectedShip >= ships.Count)
        {
            selectedShip = 0;
        }
        ShowShip();

    }

    void ShowPrevious()
    {
        selectedShip--;
        if (selectedShip < 0)
        {
            selectedShip = ships.Count - 1;
        }

        ShowShip();
    }

    void ShowShip()
    {
        actionButton.onClick.RemoveAllListeners();
        actionButton.interactable = true;
        ShipSO _shipData = ShipSO.Get(selectedShip);

        if (DataManager.Instance.PlayerData.OwnedShips.Contains(selectedShip))
        {
            actionButton.onClick.AddListener(Equipt);
            actionText.text = "Select";
        }
        else
        {
            actionButton.onClick.AddListener(Buy);
            actionText.text = "Buy: " + _shipData.UnlockCost;
        }

        if (DataManager.Instance.PlayerData.SelectedShip == selectedShip)
        {
            actionButton.interactable = false;
            actionText.text = "Equipted";
        }

        shipDisplay.sprite = _shipData.Sprite;
    }

    void Equipt()
    {
        DataManager.Instance.PlayerData.SelectedShip = selectedShip;
        ShowShip();
    }

    void Buy()
    {
        ShipSO _shipData = ShipSO.Get(selectedShip);
        if (DataManager.Instance.PlayerData.Gold >= _shipData.UnlockCost)
        {
            DataManager.Instance.PlayerData.UnlockShip(_shipData.Id);
            DataManager.Instance.PlayerData.Gold -= _shipData.UnlockCost;

            ShowShip();
            ShowGold();
        }
    }
}
