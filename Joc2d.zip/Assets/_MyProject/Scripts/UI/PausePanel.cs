using UnityEngine;
using UnityEngine.UI;

public class PausePanel : MonoBehaviour
{
    [SerializeField] Button closeButton;
    [SerializeField] Button menuButton;

    private void OnEnable()
    {
        closeButton.onClick.AddListener(Close);
        menuButton.onClick.AddListener(ShowMenu);
        Time.timeScale = 0;
    }

    private void OnDisable()
    {
        closeButton.onClick.RemoveListener(Close);
        menuButton.onClick.RemoveListener(ShowMenu);
        Time.timeScale = 1;
    }

    public void Close()
    {
        gameObject.SetActive(false);
    }

    void ShowMenu()
    {
        SceneManager.LoadMainMenu();
    }

    public void Setup()
    {
        gameObject.SetActive(true);
    }

}
