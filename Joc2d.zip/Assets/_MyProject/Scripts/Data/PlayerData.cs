using System.Collections.Generic;
using System;
using Newtonsoft.Json;

[Serializable]
public class PlayerData
{
    int gold;
    List<int> ownedShips;
    bool playMusic;
    bool playSound;
    int selectedShip;

    [JsonIgnore] public static Action UpdatedGold;
    [JsonIgnore] public static Action UpdatedOwnedShips;
    [JsonIgnore] public static Action UpdatedMusic;
    [JsonIgnore] public static Action UpdatedSound;
    [JsonIgnore] public static Action UpdatedSelectedShip;

    public int Gold
    {
        get
        {
            return gold;
        }
        set
        {
            gold = value;
            UpdatedGold?.Invoke();
        }
    }

    public List<int> OwnedShips
    {
        get
        {
            return ownedShips;
        }
        set
        {
            ownedShips = value;
            UpdatedOwnedShips?.Invoke();
        }
    }

    public void UnlockShip(int _shipId)
    {
        ownedShips.Add(_shipId);
        UpdatedOwnedShips?.Invoke();
    }

    public bool PlayMusic
    {
        get
        {
            return playMusic;
        }
        set
        {
            playMusic = value;
            UpdatedMusic?.Invoke();
        }
    }

    public bool PlaySound
    {
        get
        {
            return playSound;
        }
        set
        {
            playSound = value;
            UpdatedSound?.Invoke();
        }
    }

    public int SelectedShip
    {
        get
        {
            return selectedShip;
        }
        set
        {
            selectedShip = value;
            UpdatedSelectedShip?.Invoke();
        }
    }
}
