using UnityEngine;

public class AudioManager : MonoBehaviour
{
    public static AudioManager Instance;

    [SerializeField] AudioSource audioSource;
    [SerializeField] AudioClip explosionEffect;
    [SerializeField] AudioClip shootEffect;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void OnDisable()
    {
        PlayerData.UpdatedMusic -= ManageAudio;
    }

    public void Init()
    {
        ManageAudio();

        PlayerData.UpdatedMusic += ManageAudio;
    }


    void ManageAudio()
    {
        if (DataManager.Instance.PlayerData.PlayMusic)
        {
            audioSource.Play();
        }
        else
        {
            audioSource.Stop();
        }
    }

    public void PlayShootEffect()
    {
        PlaySoundEffect(shootEffect);
    }

    public void PlayExplosion()
    {
        PlaySoundEffect(explosionEffect);
    }

    void PlaySoundEffect(AudioClip _clip)
    {
        if (!DataManager.Instance.PlayerData.PlaySound)
        {
            return;
        }

        audioSource.PlayOneShot(_clip);
    }
}
