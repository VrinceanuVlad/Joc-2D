using UnityEngine;
using Newtonsoft.Json;
using System.Collections.Generic;

public class DataManager : MonoBehaviour
{
    public static DataManager Instance;

    const string PLAYER_DATA = "PlayerData";

    public PlayerData PlayerData { get; private set; }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void OnDisable()
    {
        PlayerData.UpdatedGold -= SavePlayerData;
        PlayerData.UpdatedMusic -= SavePlayerData;
        PlayerData.UpdatedOwnedShips -= SavePlayerData;
        PlayerData.UpdatedSelectedShip -= SavePlayerData;
        PlayerData.UpdatedSound -= SavePlayerData;
    }

    public void Init()
    {
        if (PlayerPrefs.HasKey(PLAYER_DATA))
        {
            PlayerData = JsonConvert.DeserializeObject<PlayerData>(PlayerPrefs.GetString(PLAYER_DATA));
        }
        else
        {
            PlayerData = new PlayerData();
            PlayerData.Gold = 0;
            PlayerData.OwnedShips = new List<int>() { 0 };
            PlayerData.SelectedShip = 0;
            PlayerData.PlayMusic = true;
            PlayerData.PlaySound = true;
            SavePlayerData();
        }

        PlayerData.UpdatedGold += SavePlayerData;
        PlayerData.UpdatedMusic += SavePlayerData;
        PlayerData.UpdatedOwnedShips += SavePlayerData;
        PlayerData.UpdatedSelectedShip += SavePlayerData;
        PlayerData.UpdatedSound += SavePlayerData;
    }

    void SavePlayerData()
    {
        PlayerPrefs.SetString(PLAYER_DATA, JsonConvert.SerializeObject(PlayerData));
    }
}
