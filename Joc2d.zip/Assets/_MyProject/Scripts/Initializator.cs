using UnityEngine;

public class Initializator : MonoBehaviour
{
    void Start()
    {
        InitSOs();
    }

    void InitSOs()
    {
        ShipSO.Init();
        InitDataManager();
    }

    void InitDataManager()
    {
        DataManager.Instance.Init();
        InitAudioManager();
    }

    void InitAudioManager()
    {
        AudioManager.Instance.Init();
        FinishInit();
    }

    void FinishInit()
    {
        SceneManager.LoadMainMenu();
    }
}
