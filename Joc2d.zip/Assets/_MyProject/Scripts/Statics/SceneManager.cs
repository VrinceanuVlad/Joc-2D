public static class SceneManager
{
    const string GAMEPLAY_KEY = "Gameplay";
    const string MAINMENU_KEY = "MainMenu";

    public static void LoadMainMenu()
    {
        LoadScene(MAINMENU_KEY);
    }

    public static void LoadGameplay()
    {
        LoadScene(GAMEPLAY_KEY);
    }

    static void LoadScene(string _key)
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene(_key);
    }
}
