using UnityEngine;

public class AsteroidController : MonoBehaviour
{
    float flySpeed;
    Transform myTransform;

    public void Setup(Vector3 _spawnPosition, float _flySpeed)
    {
        transform.position = _spawnPosition;
        flySpeed = _flySpeed;
    }

    private void Awake()
    {
        myTransform = GetComponent<Transform>();
    }


    private void FixedUpdate()
    {
        if (flySpeed == default)
        {
            return;
        }
        myTransform.position = Vector3.MoveTowards(myTransform.position, myTransform.position + Vector3.down, flySpeed * Time.deltaTime);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "LevelBoundries")
        {
            Destroy(gameObject);
        }
        else if (collision.tag == "MyShip")
        {
            GameplayManager.Instance.Lost();
        }
    }
}
