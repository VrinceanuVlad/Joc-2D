using UnityEngine;

public class AsteroidSpawner : MonoBehaviour
{
    [SerializeField] float spawnDelay;
    [SerializeField] float minFlySpeed;
    [SerializeField] float maxFlySpeed;
    [SerializeField] AsteroidController asteroidPrefab;
    [SerializeField] Transform leftBoundrie;
    [SerializeField] Transform rightBoundrie;
    float counter = 0;

    private void Update()
    {
        counter += Time.deltaTime;
        if (counter > spawnDelay)
        {
            counter = 0;
            Vector3 _spawnPosition = new Vector3();
            _spawnPosition.x = Random.Range(leftBoundrie.position.x, rightBoundrie.position.x);
            _spawnPosition.y = leftBoundrie.position.y;
            AsteroidController _asteroid = Instantiate(asteroidPrefab);

            float _flySpeed = Random.Range(minFlySpeed, maxFlySpeed);
            _asteroid.Setup(_spawnPosition, _flySpeed);
        }
    }
}
