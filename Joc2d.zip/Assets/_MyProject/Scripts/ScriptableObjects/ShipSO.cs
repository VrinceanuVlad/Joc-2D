using System.Collections.Generic;
using System.Linq;
using UnityEngine;

[CreateAssetMenu(fileName = "NewShip", menuName = "ScriptableObjects/Ship")]
public class ShipSO : ScriptableObject
{
    [field: SerializeField] public int Id { get; private set; }
    [field: SerializeField] public int UnlockCost { get; private set; }
    [field: SerializeField] public Sprite Sprite { get; private set; }

    static List<ShipSO> allShips;

    public static void Init()
    {
        allShips = Resources.LoadAll<ShipSO>("Ships/").ToList();
    }

    public static List<ShipSO> GetAll()
    {
        return allShips;
    }

    public static ShipSO Get(int _shipId)
    {
        return allShips.Find(element => element.Id == _shipId);
    }
}
