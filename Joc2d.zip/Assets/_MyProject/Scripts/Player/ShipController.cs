using System.Collections;
using UnityEngine;

public class ShipController : MonoBehaviour
{
    [SerializeField] float speed;
    [SerializeField] float ShootCooldown;
    [SerializeField] Transform shootPointer;
    [SerializeField] Bullet bulletPrefab;
    delegate Vector3 GetPositionHandler();
    GetPositionHandler GetPosition;
    Camera mainCamera;
    Transform myTransform;
    bool canShoot = true;
    SpriteRenderer spriteRenderer;

    private void Awake()
    {
        if (Application.platform == RuntimePlatform.Android)
        {
            GetPosition = GetPositionPhone;
        }
        else
        {
            GetPosition = GetPositionPC;
        }
        spriteRenderer = GetComponent<SpriteRenderer>();
        mainCamera = Camera.main;
        myTransform = GetComponent<Transform>();
    }

    Vector3 GetPositionPhone()
    {
        if (Input.touchCount == 0)
        {
            return default;
        }

        return Input.GetTouch(0).position;
    }

    Vector3 GetPositionPC()
    {
        return Input.mousePosition;
    }

    private void OnEnable()
    {
        ShootInput.Shoot += HandleShoot;
    }

    private void OnDisable()
    {
        ShootInput.Shoot -= HandleShoot;
    }

    void HandleShoot()
    {
        if (!canShoot)
        {
            return;
        }

        Bullet _bullet = Instantiate(bulletPrefab);
        _bullet.transform.position = shootPointer.position;
        StartCoroutine(ShootCooldownRoutine());
    }

    IEnumerator ShootCooldownRoutine()
    {
        canShoot = false;
        yield return new WaitForSeconds(ShootCooldown);
        canShoot = true;
    }

    private void Start()
    {
        spriteRenderer.sprite = ShipSO.Get(DataManager.Instance.PlayerData.SelectedShip).Sprite;
    }

    private void FixedUpdate()
    {
        if (Helpers.IsOverUI())
        {
            return;
        }
        Vector3 _screenPosition = GetPosition();
        if (_screenPosition == default)
        {
            return;
        }
        Vector2 _newPosition = mainCamera.ScreenToWorldPoint(_screenPosition);
        _newPosition.y = myTransform.position.y;
        myTransform.position = Vector2.MoveTowards(myTransform.position, _newPosition, speed * Time.deltaTime);
    }
}
