using System;
using UnityEngine;
using UnityEngine.UI;

public class ShootInput : MonoBehaviour
{
    public static Action Shoot;
    [SerializeField] Button shootButton;

    private void OnEnable()
    {
        shootButton.onClick.AddListener(TriggerShoot);
    }

    private void OnDisable()
    {
        shootButton.onClick.RemoveListener(TriggerShoot);
    }

    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            TriggerShoot();
        }
    }

    void TriggerShoot()
    {
        Shoot?.Invoke();
    }
}
