using UnityEngine;

public class Bullet : MonoBehaviour
{
    [SerializeField] Vector3 flyDirection;
    [SerializeField] float flySpeed;
    Transform myTransform;

    private void Awake()
    {
        myTransform = GetComponent<Transform>();
    }

    private void OnEnable()
    {
        AudioManager.Instance.PlayShootEffect();
    }

    private void FixedUpdate()
    {
        myTransform.position = Vector3.MoveTowards(myTransform.position, myTransform.position + flyDirection, flySpeed * Time.deltaTime);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "LevelBoundries")
        {
            Destroy(gameObject);
        }
        else if (collision.tag == "MyShip")
        {
            AudioManager.Instance.PlayExplosion();
            GameplayManager.Instance.Lost();
        }
    }
}
